# MY-NOTEPAD
# A note pad made in python using Tkinter (GUI).

Hope you'll install it in your computer just to try .

icons2 folder contains all the icons used in this Program.

Notepad.py is where all the main code is written.

mainicon.ico is the main icon which will apperar after installing this Notepad.

Notepad -0.01-amd64.msi is the setup of this Notepad .

setup.py is the file used to make the setup of the Notepad.

You can install it on your computer on Windows .


How to install. Open -> Notepad -0.01-amd64.msi on your computer a download manager will pop up and  will ask for some permissions to install. 


# Functionality to be added undo and redo to add more flexibility to it. 

